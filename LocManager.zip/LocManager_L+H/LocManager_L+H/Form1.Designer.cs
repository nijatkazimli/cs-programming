﻿namespace LocManager_L_H
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            menuStrip = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            openToolStripMenuItem = new ToolStripMenuItem();
            saveAsToolStripMenuItem1 = new ToolStripMenuItem();
            editToolStripMenuItem = new ToolStripMenuItem();
            newEntryToolStripMenuItem = new ToolStripMenuItem();
            deleteEntryToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            splitContainer1 = new SplitContainer();
            treeView = new TreeView();
            imageList = new ImageList(components);
            tabControl = new TabControl();
            searchTabPage = new TabPage();
            searchListView = new ListView();
            lockey = new ColumnHeader();
            path = new ColumnHeader();
            debug = new ColumnHeader();
            searchButton = new Button();
            searchTextBox = new TextBox();
            detailsTabPage = new TabPage();
            tableLayoutPanel1 = new TableLayoutPanel();
            listView = new ListView();
            groupBox1 = new GroupBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            openFileDialog = new OpenFileDialog();
            statusStrip = new StatusStrip();
            toolStripSplitButton1 = new ToolStripSplitButton();
            toolStripMenuItem1 = new ToolStripMenuItem();
            toolStripMenuItem3 = new ToolStripMenuItem();
            toolStripMenuItem2 = new ToolStripMenuItem();
            toolStripMenuItem4 = new ToolStripMenuItem();
            toolStripMenuItem5 = new ToolStripMenuItem();
            toolStripStatusLabel1 = new ToolStripStatusLabel();
            toolStripProgressBar1 = new ToolStripProgressBar();
            contextMenuStrip1 = new ContextMenuStrip(components);
            newGroupToolStripMenuItem = new ToolStripMenuItem();
            newSubgroupToolStripMenuItem = new ToolStripMenuItem();
            deleteGroupToolStripMenuItem = new ToolStripMenuItem();
            errorProvider1 = new ErrorProvider(components);
            menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            tabControl.SuspendLayout();
            searchTabPage.SuspendLayout();
            detailsTabPage.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            groupBox1.SuspendLayout();
            statusStrip.SuspendLayout();
            contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // menuStrip
            // 
            menuStrip.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, editToolStripMenuItem, helpToolStripMenuItem });
            menuStrip.Location = new Point(0, 0);
            menuStrip.Name = "menuStrip";
            menuStrip.Size = new Size(784, 24);
            menuStrip.TabIndex = 0;
            menuStrip.Text = "menuStrip";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { openToolStripMenuItem, saveAsToolStripMenuItem1 });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            openToolStripMenuItem.Name = "openToolStripMenuItem";
            openToolStripMenuItem.Size = new Size(123, 22);
            openToolStripMenuItem.Text = "Open";
            openToolStripMenuItem.Click += openToolStripMenuItem_Click;
            // 
            // saveAsToolStripMenuItem1
            // 
            saveAsToolStripMenuItem1.Name = "saveAsToolStripMenuItem1";
            saveAsToolStripMenuItem1.Size = new Size(123, 22);
            saveAsToolStripMenuItem1.Text = "Save As ..";
            saveAsToolStripMenuItem1.Click += saveAsToolStripMenuItem1_Click;
            // 
            // editToolStripMenuItem
            // 
            editToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { newEntryToolStripMenuItem, deleteEntryToolStripMenuItem });
            editToolStripMenuItem.Name = "editToolStripMenuItem";
            editToolStripMenuItem.Size = new Size(39, 20);
            editToolStripMenuItem.Text = "Edit";
            // 
            // newEntryToolStripMenuItem
            // 
            newEntryToolStripMenuItem.Name = "newEntryToolStripMenuItem";
            newEntryToolStripMenuItem.Size = new Size(161, 22);
            newEntryToolStripMenuItem.Text = "New Entry";
            newEntryToolStripMenuItem.Click += newEntryToolStripMenuItem_Click;
            // 
            // deleteEntryToolStripMenuItem
            // 
            deleteEntryToolStripMenuItem.Name = "deleteEntryToolStripMenuItem";
            deleteEntryToolStripMenuItem.ShortcutKeys = Keys.Delete;
            deleteEntryToolStripMenuItem.Size = new Size(161, 22);
            deleteEntryToolStripMenuItem.Text = "Delete Entry";
            deleteEntryToolStripMenuItem.Click += deleteEntryToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(44, 20);
            helpToolStripMenuItem.Text = "Help";
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 24);
            splitContainer1.Margin = new Padding(3, 3, 3, 20);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(treeView);
            splitContainer1.Panel1.Margin = new Padding(0, 0, 0, 20);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(tabControl);
            splitContainer1.Panel2.Margin = new Padding(0, 0, 0, 20);
            splitContainer1.Size = new Size(784, 437);
            splitContainer1.SplitterDistance = 300;
            splitContainer1.TabIndex = 1;
            // 
            // treeView
            // 
            treeView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            treeView.ImageKey = "folder.ico";
            treeView.ImageList = imageList;
            treeView.Location = new Point(0, 0);
            treeView.Margin = new Padding(3, 3, 3, 20);
            treeView.Name = "treeView";
            treeView.PathSeparator = "-";
            treeView.SelectedImageKey = "folder.ico";
            treeView.Size = new Size(300, 408);
            treeView.TabIndex = 0;
            treeView.AfterLabelEdit += treeView_AfterLabelEdit;
            treeView.AfterSelect += treeView_AfterSelect;
            treeView.MouseDown += treeView_MouseDown;
            // 
            // imageList
            // 
            imageList.ColorDepth = ColorDepth.Depth8Bit;
            imageList.ImageStream = (ImageListStreamer)resources.GetObject("imageList.ImageStream");
            imageList.TransparentColor = Color.Transparent;
            imageList.Images.SetKeyName(0, "file.ico");
            imageList.Images.SetKeyName(1, "folder.ico");
            // 
            // tabControl
            // 
            tabControl.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tabControl.Controls.Add(searchTabPage);
            tabControl.Controls.Add(detailsTabPage);
            tabControl.Location = new Point(0, 0);
            tabControl.Name = "tabControl";
            tabControl.SelectedIndex = 0;
            tabControl.Size = new Size(480, 412);
            tabControl.TabIndex = 0;
            tabControl.SelectedIndexChanged += tabControl_SelectedIndexChanged;
            // 
            // searchTabPage
            // 
            searchTabPage.Controls.Add(searchListView);
            searchTabPage.Controls.Add(searchButton);
            searchTabPage.Controls.Add(searchTextBox);
            searchTabPage.Location = new Point(4, 24);
            searchTabPage.Name = "searchTabPage";
            searchTabPage.Padding = new Padding(3);
            searchTabPage.Size = new Size(472, 384);
            searchTabPage.TabIndex = 0;
            searchTabPage.Text = "Search";
            searchTabPage.UseVisualStyleBackColor = true;
            // 
            // searchListView
            // 
            searchListView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            searchListView.Columns.AddRange(new ColumnHeader[] { lockey, path, debug });
            searchListView.Location = new Point(6, 35);
            searchListView.Name = "searchListView";
            searchListView.Size = new Size(458, 343);
            searchListView.TabIndex = 2;
            searchListView.UseCompatibleStateImageBehavior = false;
            searchListView.View = View.Details;
            searchListView.MouseDoubleClick += searchListView_MouseDoubleClick;
            // 
            // lockey
            // 
            lockey.Text = "LocKey";
            // 
            // path
            // 
            path.Text = "Path";
            path.Width = 100;
            // 
            // debug
            // 
            debug.Text = "Debug";
            debug.Width = 294;
            // 
            // searchButton
            // 
            searchButton.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            searchButton.Location = new Point(389, 6);
            searchButton.Name = "searchButton";
            searchButton.Size = new Size(75, 23);
            searchButton.TabIndex = 1;
            searchButton.Text = "Search";
            searchButton.UseVisualStyleBackColor = true;
            searchButton.Click += searchButton_Click;
            // 
            // searchTextBox
            // 
            searchTextBox.Location = new Point(6, 6);
            searchTextBox.Name = "searchTextBox";
            searchTextBox.Size = new Size(377, 23);
            searchTextBox.TabIndex = 0;
            searchTextBox.TextChanged += searchTextBox_TextChanged;
            searchTextBox.KeyDown += searchTextBox_KeyDown;
            // 
            // detailsTabPage
            // 
            detailsTabPage.Controls.Add(tableLayoutPanel1);
            detailsTabPage.Location = new Point(4, 24);
            detailsTabPage.Name = "detailsTabPage";
            detailsTabPage.Padding = new Padding(3);
            detailsTabPage.Size = new Size(472, 384);
            detailsTabPage.TabIndex = 1;
            detailsTabPage.Text = "Details";
            detailsTabPage.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Controls.Add(listView, 0, 1);
            tableLayoutPanel1.Controls.Add(groupBox1, 0, 0);
            tableLayoutPanel1.Location = new Point(-4, 3);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(488, 382);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // listView
            // 
            listView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            listView.Location = new Point(10, 212);
            listView.Margin = new Padding(10, 3, 15, 3);
            listView.Name = "listView";
            listView.Size = new Size(463, 167);
            listView.TabIndex = 1;
            listView.UseCompatibleStateImageBehavior = false;
            listView.View = View.Details;
            // 
            // groupBox1
            // 
            groupBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Location = new Point(0, 3);
            groupBox1.Margin = new Padding(0, 3, 0, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(488, 203);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Translation Details";
            // 
            // textBox2
            // 
            textBox2.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            textBox2.Location = new Point(10, 47);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(463, 150);
            textBox2.TabIndex = 1;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            textBox1.Location = new Point(10, 18);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(463, 23);
            textBox1.TabIndex = 0;
            textBox1.TextAlign = HorizontalAlignment.Center;
            textBox1.Enter += textBox1_Enter;
            textBox1.KeyDown += textBox1_KeyDown;
            // 
            // openFileDialog
            // 
            openFileDialog.Filter = "ZIP files (*.zip)|*.zip";
            // 
            // statusStrip
            // 
            statusStrip.Items.AddRange(new ToolStripItem[] { toolStripSplitButton1, toolStripStatusLabel1, toolStripProgressBar1 });
            statusStrip.Location = new Point(0, 439);
            statusStrip.Name = "statusStrip";
            statusStrip.Size = new Size(784, 22);
            statusStrip.TabIndex = 2;
            statusStrip.Text = "statusStrip1";
            // 
            // toolStripSplitButton1
            // 
            toolStripSplitButton1.DisplayStyle = ToolStripItemDisplayStyle.Text;
            toolStripSplitButton1.DropDownItems.AddRange(new ToolStripItem[] { toolStripMenuItem1, toolStripMenuItem3, toolStripMenuItem2, toolStripMenuItem4, toolStripMenuItem5 });
            toolStripSplitButton1.ImageTransparentColor = Color.Magenta;
            toolStripSplitButton1.Name = "toolStripSplitButton1";
            toolStripSplitButton1.Size = new Size(69, 20);
            toolStripSplitButton1.Text = "Translate";
            toolStripSplitButton1.ButtonClick += toolStripSplitButton1_ButtonClick;
            toolStripSplitButton1.DropDownItemClicked += toolStripSplitButton1_DropDownItemClicked;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(127, 22);
            toolStripMenuItem1.Text = "English";
            // 
            // toolStripMenuItem3
            // 
            toolStripMenuItem3.Name = "toolStripMenuItem3";
            toolStripMenuItem3.Size = new Size(127, 22);
            toolStripMenuItem3.Text = "Polish";
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.Size = new Size(127, 22);
            toolStripMenuItem2.Text = "Spanish";
            // 
            // toolStripMenuItem4
            // 
            toolStripMenuItem4.Name = "toolStripMenuItem4";
            toolStripMenuItem4.Size = new Size(127, 22);
            toolStripMenuItem4.Text = "Portugese";
            // 
            // toolStripMenuItem5
            // 
            toolStripMenuItem5.Name = "toolStripMenuItem5";
            toolStripMenuItem5.Size = new Size(127, 22);
            toolStripMenuItem5.Text = "Chinese";
            // 
            // toolStripStatusLabel1
            // 
            toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            toolStripStatusLabel1.Size = new Size(598, 17);
            toolStripStatusLabel1.Spring = true;
            // 
            // toolStripProgressBar1
            // 
            toolStripProgressBar1.Alignment = ToolStripItemAlignment.Right;
            toolStripProgressBar1.Name = "toolStripProgressBar1";
            toolStripProgressBar1.Size = new Size(100, 16);
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { newGroupToolStripMenuItem, newSubgroupToolStripMenuItem, deleteGroupToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(154, 70);
            // 
            // newGroupToolStripMenuItem
            // 
            newGroupToolStripMenuItem.Name = "newGroupToolStripMenuItem";
            newGroupToolStripMenuItem.Size = new Size(153, 22);
            newGroupToolStripMenuItem.Text = "New Group";
            newGroupToolStripMenuItem.Click += newGroupToolStripMenuItem_Click;
            // 
            // newSubgroupToolStripMenuItem
            // 
            newSubgroupToolStripMenuItem.Name = "newSubgroupToolStripMenuItem";
            newSubgroupToolStripMenuItem.Size = new Size(153, 22);
            newSubgroupToolStripMenuItem.Text = "New Subgroup";
            newSubgroupToolStripMenuItem.Click += newSubgroupToolStripMenuItem_Click;
            // 
            // deleteGroupToolStripMenuItem
            // 
            deleteGroupToolStripMenuItem.Name = "deleteGroupToolStripMenuItem";
            deleteGroupToolStripMenuItem.Size = new Size(153, 22);
            deleteGroupToolStripMenuItem.Text = "Delete Group";
            deleteGroupToolStripMenuItem.Click += deleteGroupToolStripMenuItem_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(784, 461);
            Controls.Add(statusStrip);
            Controls.Add(splitContainer1);
            Controls.Add(menuStrip);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MainMenuStrip = menuStrip;
            MinimumSize = new Size(800, 500);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "LocManager";
            Load += Form1_Load;
            menuStrip.ResumeLayout(false);
            menuStrip.PerformLayout();
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            tabControl.ResumeLayout(false);
            searchTabPage.ResumeLayout(false);
            searchTabPage.PerformLayout();
            detailsTabPage.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            statusStrip.ResumeLayout(false);
            statusStrip.PerformLayout();
            contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem openToolStripMenuItem;
        private ToolStripMenuItem saveAsToolStripMenuItem1;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem newEntryToolStripMenuItem;
        private ToolStripMenuItem deleteEntryToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private SplitContainer splitContainer1;
        private TreeView treeView;
        private TabControl tabControl;
        private TabPage detailsTabPage;
        private OpenFileDialog openFileDialog;
        private TableLayoutPanel tableLayoutPanel;
        private GroupBox groupBoxUpper;
        //private TextBox textBox;
        //private TextBox ReadOnlytextBox;
        private ListView listView;
        private TabPage searchTabPage;
        private TableLayoutPanel tableLayoutPanel1;
        private GroupBox groupBox1;
        private TextBox textBox2;
        private TextBox textBox1;
        private StatusStrip statusStrip;
        private ImageList imageList;
        private ListView searchListView;
        private ColumnHeader lockey;
        private ColumnHeader path;
        private ColumnHeader debug;
        private Button searchButton;
        private TextBox searchTextBox;
        private ToolStripSplitButton toolStripSplitButton1;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripMenuItem toolStripMenuItem3;
        private ToolStripMenuItem toolStripMenuItem4;
        private ToolStripMenuItem toolStripMenuItem5;
        private ToolStripProgressBar toolStripProgressBar1;
        private ToolStripStatusLabel toolStripStatusLabel1;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem newGroupToolStripMenuItem;
        private ToolStripMenuItem newSubgroupToolStripMenuItem;
        private ToolStripMenuItem deleteGroupToolStripMenuItem;
        private ErrorProvider errorProvider1;
    }
}