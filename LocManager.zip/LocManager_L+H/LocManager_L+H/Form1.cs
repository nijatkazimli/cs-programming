using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;
using System.IO.Compression;
using Newtonsoft.Json;
using System.Windows.Forms;
using System.Drawing;
using System.Transactions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Linq;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using Microsoft.VisualBasic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace LocManager_L_H
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            tabControl.SelectedIndex = 1;
        }


        List<JsonData> jsonDatas = new List<JsonData>();
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog.InitialDirectory = Environment.CurrentDirectory;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                treeView.Nodes.Clear();
                using (var zipArchive = ZipFile.OpenRead(openFileDialog.FileName))
                {
                    foreach (var entry in zipArchive.Entries)
                    {
                        if (entry.FullName.EndsWith(".json"))
                        {
                            // Read the contents of the JSON file
                            using (var streamReader = new StreamReader(entry.Open()))
                            {
                                var jsonString = streamReader.ReadToEnd();
                                var jsonObject = JsonConvert.DeserializeObject<JsonData>(jsonString);
                                jsonDatas.Add(jsonObject);

                                // Add the JSON data to the TreeView
                                var node = treeView.Nodes;
                                var path = jsonObject.HierarchyPath.Split('-');
                                for (var i = 0; i < path.Length; i++)
                                {
                                    if (node.ContainsKey(path[i]))
                                    {
                                        node = node[path[i]].Nodes;
                                    }
                                    else
                                    {
                                        var newNode = node.Add(path[i], path[i]);
                                        node = newNode.Nodes;
                                    }
                                }
                                var newNodeEntry = new TreeNode(jsonObject.EntryName);
                                newNodeEntry.Tag = jsonObject;
                                newNodeEntry.ImageKey = "file.ico";
                                newNodeEntry.SelectedImageKey = "file.ico";
                                //node.Add(new TreeNode(jsonObject.EntryName));
                                node.Add(newNodeEntry);

                            }
                        }
                    }
                }
            }

        }

        bool isCreatingNewEntry = false;
        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Tag is JsonData jsonData && !isCreatingNewEntry)
            {
                textBox1.Text = e.Node.FullPath.Replace('\\', '-');
                textBox2.Text = jsonData.Translations["Debug"];

                listView.Items.Clear();
                if (listView.Columns.Count == 0)
                {
                    listView.Columns.Add("Language", 80, HorizontalAlignment.Left);
                    listView.Columns.Add("Translation", 370, HorizontalAlignment.Left);
                }
                foreach (var translation in jsonData.Translations)
                {
                    var listViewItem = new ListViewItem(new[] { translation.Key, translation.Value });
                    listView.Items.Add(listViewItem);
                }
                tabControl.SelectedIndex = 1;
            }
            if (e.Node.Tag is not JsonData && !isCreatingNewEntry)  /// CHANGED
            {
                textBox1.Text = String.Empty;
                textBox2.Text = String.Empty;
                listView.Items.Clear();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (listView.Items.Count > 0)
            {
                ListViewItem firstItem = listView.Items[0];
                firstItem.SubItems[1].Text = textBox2.Text;
                if (treeView.SelectedNode.Tag is JsonData data)
                {
                    data.Translations[firstItem.SubItems[0].Text] = textBox2.Text;
                }
            }
        }

        bool isSearchable = false;
        private void searchButton_Click(object sender, EventArgs e)
        {
            if (!isSearchable)
            {
                searchListView.Items.Clear();

                string searchText = searchTextBox.Text.ToLower();

                foreach (TreeNode node in treeView.Nodes)
                {
                    NodeSearching(node, searchText);
                }
            }
        }

        private void NodeSearching(TreeNode node, string searchText)
        {
            if (node.Tag is JsonData jsonData)
            {
                if (jsonData.LocKey.ToLower().Contains(searchText) ||
                    jsonData.HierarchyPath.ToLower().Contains(searchText) ||
                    jsonData.Translations["Debug"].ToLower().Contains(searchText))
                {
                    var item = new ListViewItem(new[] { "LocKey#" + jsonData.LocKey, jsonData.HierarchyPath + "-" + jsonData.EntryName, jsonData.Translations["Debug"] });

                    searchListView.Items.Add(item);
                }
            }

            foreach (TreeNode childNode in node.Nodes)
            {
                NodeSearching(childNode, searchText);
            }
        }

        private void searchListView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (searchListView.SelectedItems.Count > 0)
            {
                var selectedItem = searchListView.SelectedItems[0];
                var locKey = selectedItem.SubItems[0].Text;
                locKey = locKey.Remove(0, 7);
                var node = FindNodeByLocKey(treeView.Nodes, locKey);
                if (node != null)
                {
                    treeView.SelectedNode = node;
                    treeView.Select();
                    tabControl.SelectedIndex = 1;
                }
            }
        }

        private TreeNode FindNodeByLocKey(TreeNodeCollection nodes, string locKey)
        {
            foreach (TreeNode node in nodes)
            {
                if (node.Tag is JsonData jsonData && jsonData.LocKey == locKey)
                {
                    return node;
                }

                if (node.Nodes.Count > 0)
                {
                    TreeNode foundNode = FindNodeByLocKey(node.Nodes, locKey);
                    if (foundNode != null)
                    {
                        return foundNode;
                    }
                }
            }

            return null;
        }

        private void treeView_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                treeView.SelectedNode = treeView.GetNodeAt(e.X, e.Y);

                if (treeView.SelectedNode != null && treeView.SelectedNode.Tag is not JsonData)
                {
                    contextMenuStrip1.Show(treeView, e.Location);
                }
            }
        }

        private void newGroupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int level = treeView.SelectedNode.Level;
            if (treeView.Nodes.Count == 1 && treeView.Nodes[0].Tag is bool isDefault == true)
            {
                treeView.Nodes.RemoveAt(0);
                level = 0;
            }
            var newNode = new TreeNode("<NEW GROUP>");

            if (level == 0)
                treeView.Nodes.Add(newNode);
            else
            {
                TreeNode parentNode = treeView.SelectedNode.Parent;
                parentNode.Nodes.Add(newNode);
            }
            //TreeNode parentNode = (level == 0) ? treeView.Nodes : treeView.SelectedNode.Parent.Parent;
            //parentNode.Nodes.Add(newNode);
            treeView.LabelEdit = true;
            newNode.BeginEdit();
        }

        private void newSubgroupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newNode = new TreeNode("<NEW SUBGROUP>");

            treeView.SelectedNode.Nodes.Add(newNode);

            treeView.SelectedNode.Expand();
            treeView.LabelEdit = true;
            newNode.BeginEdit();
        }

        private void deleteGroupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            treeView.SelectedNode.Remove();
            if(treeView.Nodes.Count == 0)
            {
                TreeNode root = new TreeNode();
                root.Text = "<ROOT>";
                bool isDefault = true;
                root.Tag = isDefault;
                treeView.Nodes.Add(root);
            }
        }

        private void treeView_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            treeView.LabelEdit = false;
        }

        private void deleteEntryToolStripMenuItem_Click(object sender, EventArgs e) // EVENT
        {
            if (treeView.SelectedNode != null && treeView.SelectedNode.Tag is JsonData)
            {
                searchListView.Items.Clear();
                treeView.SelectedNode.Remove();
            }
        }

        TreeNode node; /// CHAAANGEEEE
        private void newEntryToolStripMenuItem_Click(object sender, EventArgs e) // EVENT
        {
            if (treeView.SelectedNode != null && treeView.SelectedNode.Tag is not JsonData)
            {
                isCreatingNewEntry = true;
                tabControl.SelectedIndex = 1;
                textBox1.ReadOnly = false;
                //textBox1.BackColor = SystemColors.ControlLight;
                textBox1.Clear();
                textBox1.Text = treeView.SelectedNode.FullPath + "-";
                textBox1.Focus();

                node = treeView.SelectedNode;
                //var hierarchyPath = ((JsonData)selectedNode.Tag).HierarchyPath + "-" + selectedNode.Text;

                // var locKey = Guid.NewGuid().ToString();
                var newEntry = new JsonData
                {
                    HierarchyPath = "",
                    LocKey = "",
                    Translations = new Dictionary<string, string>(),
                    EntryName = ""
                };
                newEntry.Translations.Add("Debug", "");
                textBox1.Tag = newEntry;
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e) // EVENT
        {
            if (e.KeyCode == Keys.Enter && textBox1.Tag is JsonData newEntry)
            {
                newEntry.EntryName = textBox1.Text.Substring(textBox1.Text.LastIndexOf("-") + 1);

                // var selectedNode = treeView.SelectedNode;
                var newNode = node.Nodes.Add(newEntry.EntryName, newEntry.EntryName);
                newNode.SelectedImageKey = "file.ico";
                newNode.ImageKey = "file.ico";
                node.Expand();
                newNode.Tag = newEntry;

                textBox1.ReadOnly = true;
                treeView.SelectedNode = newNode;
                newEntry.HierarchyPath = node.FullPath;
                newEntry.LocKey = $"{newEntry.HierarchyPath}-{newEntry.EntryName}".Hash();
                jsonDatas.Add(newEntry); ////////////////////////////
                isCreatingNewEntry = false;
                if (listView.Columns.Count == 0)
                {
                    listView.Columns.Add("Language", 80, HorizontalAlignment.Left);
                    listView.Columns.Add("Translation", 370, HorizontalAlignment.Left);
                }
                foreach (var translation in newEntry.Translations)
                {
                    var listViewItem = new ListViewItem(new[] { translation.Key, translation.Value });
                    listView.Items.Add(listViewItem);
                }
                //treeView.SelectedNode = newNode;
                //ClearDetailsTab();
                //tabControl.SelectedTab = tabControl.TabPages["tabPageTree"];
            }
        }

        private void textBox1_Enter(object sender, EventArgs e) // EVENT
        {
            textBox1.SelectionStart = textBox1.Text.Length;
        }

        private void saveAsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            using (var saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "Zip Files|*.zip";
                saveFileDialog.Title = "Save as Zip File";
                saveFileDialog.FileName = "LocManager.zip";
                saveFileDialog.OverwritePrompt = true;

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    /*
                    using (var zipArchive = ZipFile.Open(saveFileDialog.FileName, ZipArchiveMode.Create))
                    {
                        foreach (TreeNode rootNode in treeView.Nodes)
                        {
                            foreach (TreeNode childNode in rootNode.Nodes)
                            {
                                var jsonData = childNode.Tag as JsonData;
                                if (jsonData != null)
                                {
                                    // Add the entry to the archive
                                    var entryName = $"{jsonData.HierarchyPath}-{jsonData.EntryName}.json";
                                    var entry = zipArchive.CreateEntry(entryName);
                                    using (var streamWriter = new StreamWriter(entry.Open()))
                                    {
                                        var json = JsonConvert.SerializeObject(jsonData);
                                        streamWriter.Write(json);
                                    }
                                }
                            }
                        }*/
                    using (var newArchive = ZipFile.Open(saveFileDialog.FileName, ZipArchiveMode.Create))
                    {

                        foreach (JsonData jsonObject in jsonDatas)
                        {
                            var entryName = $"Lockey#{jsonObject.LocKey}.json";
                            var entry = newArchive.CreateEntry(entryName);
                            using (var streamWriter = new StreamWriter(entry.Open()))
                            {
                                var json = JsonConvert.SerializeObject(jsonObject);
                                streamWriter.Write(json);
                            }
                        }
                    }
                }
            }
        }

        private void toolStripSplitButton1_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e) // event
        {
            foreach (ToolStripMenuItem item in toolStripSplitButton1.DropDownItems)
            {
                if (item == e.ClickedItem)
                {
                    item.Checked = true;
                }
                else
                {
                    item.Checked = false;
                }
            }
        }

        private void toolStripSplitButton1_ButtonClick(object sender, EventArgs e) // event
        {

        }

        private void Form1_Load(object sender, EventArgs e) // event
        {
            TreeNode root = new TreeNode();
            root.Text = "<ROOT>";
            bool isDefault = true;
            root.Tag = isDefault;
            treeView.Nodes.Add(root);

            errorProvider1.SetError(searchTextBox, "Search cannot be empty.");
            errorProvider1.SetIconPadding(searchTextBox, -20);
            isSearchable = true;
        }

        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            searchListView.Items.Clear();
            searchTextBox.Text = String.Empty;
        }

        private void searchTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && !isSearchable)
            {
                searchButton_Click(sender, e);
            }
        }

        private void searchTextBox_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(searchTextBox.Text))
            {
                errorProvider1.SetError(searchTextBox, "Search cannot be empty.");
                errorProvider1.SetIconPadding(searchTextBox, -20);
                isSearchable = true;
            }
            else
            {
                errorProvider1.SetError(searchTextBox, null);
                isSearchable = false;
            }
        }
    }

}